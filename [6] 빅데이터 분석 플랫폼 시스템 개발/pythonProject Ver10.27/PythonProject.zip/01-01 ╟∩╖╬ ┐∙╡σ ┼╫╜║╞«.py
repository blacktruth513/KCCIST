print("또 월드")
print("또 월드")